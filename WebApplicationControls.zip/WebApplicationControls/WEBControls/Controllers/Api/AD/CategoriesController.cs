﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class CategoriesController : ApiController
    {
        public IEnumerable<string> Get()
        {
            return Repository.AD.ListAllCategories();
        }
    }
}
