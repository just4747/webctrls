﻿using System;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class GroupMembersController : ApiController
    {
        public Models.AD.GroupMemberWorker Get(Guid guid)
        {
            return Repository.AD.ListAD_GroupMembersAll(guid);
        }
    }
}
