﻿
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;


namespace WEBControls.Controllers.Api.AD
{
    public class GenericUsersController : ApiController
    {
        //public HttpResponseMessage Get(string term, string owner, string accountSubtype, string domain, string status, int page, int rows, string sort, string order)
        //{
        //    var response = this.Request.CreateResponse(HttpStatusCode.OK);
        //    response.Content = new StringContent(Repository.AD.SearchGenericUser(term, owner, accountSubtype, domain, status, page, rows, sort, order), Encoding.UTF8, "application/json");
        //    return response;
        //}
    }
}

