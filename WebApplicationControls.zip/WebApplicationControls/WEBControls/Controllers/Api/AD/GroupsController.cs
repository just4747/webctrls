﻿using System;
using System.Collections.Generic;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class GroupsController : ApiController
    {
        public IEnumerable<EntityControls.AD.Group> Get(string term, string domain, Guid ouGuid, bool includeEmpty)
        {
            if (!string.IsNullOrEmpty(term) && (term != "undefined") || ouGuid != Guid.Empty || !string.IsNullOrEmpty(domain))
            {
                return Repository.AD.SearchGroup(term, ouGuid, domain, includeEmpty);
            }
            else
            {
                return null;
            }
        }
    }
}
