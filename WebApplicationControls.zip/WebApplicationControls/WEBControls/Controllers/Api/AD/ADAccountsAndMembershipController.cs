﻿using System;
using System.Collections.Generic;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class ADAccountsAndMembershipController : ApiController
    {
        public IEnumerable<Models.TreeNode> Get(string id)
        {
            var objectGUID = Guid.Empty;
            if (Guid.TryParse(id, out objectGUID))
            {
                var nodesRoot = new HashSet<Models.TreeNode>();

                nodesRoot.Add(Repository.AD.ListAccountsAndMembershipOwnedBy(objectGUID));
                //nodesRoot.Add(Repository.ORACLE.ListAccountsAndMembershipOwnedBy(objectGUID));
                //nodesRoot.Add(SQLSERVER.ListAccountsAndMembership(objectGUID));

                return nodesRoot;

            }
            return null; 
        }
    }
}
