﻿using System.Collections.Generic;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class MembershipByEIDController : ApiController
    {
        //public Models.AD.Membership Get(string eid)
        //{
        //    return Repository.AD.ListMembershipByEID(eid);
        //}


        public IEnumerable<Models.TreeNode> Get(string eid)
        {
            return Repository.AD.ListMembershipByEID(eid);
        }

    }
}
