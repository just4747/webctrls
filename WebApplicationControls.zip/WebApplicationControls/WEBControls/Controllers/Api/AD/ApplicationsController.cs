﻿using System.Collections.Generic;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class ApplicationsController : ApiController
    {
        public IEnumerable<EntityControls.GEAR.Application> Get(string term, bool includeAll)
        {
            if (!string.IsNullOrEmpty(term) && (term != "undefined") )
            {
                return Repository.GEAR.SearchApplication(term, includeAll);
            }
            else
            {
                return null;
            }
        }
    }
}
