﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WEBControls.Controllers.Api.AD
{
    public class GenericUserAccountSubTypeController : ApiController
    {
        [HttpPost]
        public void Post([FromBody] XEditable data)
        {
            if(data.IsValid)
            {
                Repository.AD.SetCategory(data.GUID, data.value, User.Identity.Name);
            }
        }

        public class XEditable
        {
            public string pk { get; set; }
            public string name { get; set; }
            public string value { get; set; }
            public bool IsValid { get; set; }

            public Guid GUID { 
                get
                {
                    var guid = Guid.Empty;
                    IsValid = Guid.TryParse(pk, out guid);
                    return guid;
                }
            }

        }
            
    }
}
