﻿using System.Web.Mvc;

namespace WEBControls.Controllers
{
    //[CustomActionFilter]
    public class ADController : Controller
    {
        public ActionResult Users()
        {
            return View();
        }
        public ActionResult Groups()
        {
            return View();
        }
        public ActionResult GroupMembers()
        {
            return View();
        }

        [Authorize(Roles = @"INVESTMENTS\ABPASGControls")]
        public ActionResult GenericAccounts()
        {
            return View();
        }

        public ActionResult UsersTest()
        {
            return View();
        }
    }
}