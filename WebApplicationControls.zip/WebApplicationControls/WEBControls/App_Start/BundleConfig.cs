﻿using System.Web;
using System.Web.Optimization;

namespace WEBControls
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            var scripts = new ScriptBundle("~/bundles/scripts");
            scripts.Include("~/Scripts/jquery.loadmask.min.js");
            scripts.Include("~/Scripts/webControls.js");
            scripts.IncludeDirectory("~/Scripts/services", "*.js");
            bundles.Add(scripts);
        }
    }
}
