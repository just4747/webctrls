﻿using System;
using System.Data;


namespace DALControls.WINDOWS
{
    public static class Computers
    {
        public static DataTable ListWINDOWSAccountsOwnedBy(Guid ownerGUID)
        {
            var sql = string.Format(@"
SELECT        WINDOWS_GroupMembers.ComputerName, View_AD_Users.FullLoginID AS AccountName, View_WINDOWS_Groups.Name AS GroupName
FROM            WINDOWS_GroupMembers INNER JOIN
                         View_AD_Users ON View_AD_Users.objectSid = WINDOWS_GroupMembers.memberSid INNER JOIN
                         View_WINDOWS_Groups ON WINDOWS_GroupMembers.ComputerName = View_WINDOWS_Groups.ComputerName AND 
                         WINDOWS_GroupMembers.groupSid = View_WINDOWS_Groups.objectSid INNER JOIN
                         Ownership.View_Objects ON View_AD_Users.objectGUID = Ownership.View_Objects.ObjectGUID INNER JOIN
                         View_WorkersAll ON Ownership.View_Objects.OwnerGUID = View_WorkersAll.ObjectGUID
WHERE        (View_WorkersAll.objectGUID = '{0}')", ownerGUID);
            return ControlsDB.ExecuteText(sql);
        }
    }
}
