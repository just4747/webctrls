﻿using System.Data;
using System.Text.RegularExpressions;
namespace DALControls.HR
{
    public static class Workers
    {
        public static DataSet Load(string eid)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("loadHR_Worker", eid);
        }

        public static DataSet listHR_DirectReports(string eid)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("listHR_DirectReports", eid);
        }

        public static DataSet LoadWReportLine(string eid)
        {
            var sql = string.Format("select View_WorkersAll.EID, LastName AS [Employee Last Name], DesireName AS [Employee First Name], IsTerminated from [dbo].[GDW_ReportLine]('{0}') T inner join View_WorkersAll on View_WorkersAll.EID=T.EID where [level] > 1 order by [level] desc", eid);
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql);
        }

        public static DataSet Search(string lastName, string firstName, string managerEID, string email, string eid)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("searchHR_Workers", lastName, firstName, managerEID, email, eid);
        }


        public static DataSet Search(string companyNumber, string branchNumber, string departmentNumber, bool includeAll)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("listHR_WorkersByCBD", companyNumber, branchNumber, departmentNumber, includeAll);
        }

        public static DataTable Lookup(string term, bool includeAll)
        {
            var eidPattern = new Regex(@"^[sS]?\d{7}$");
            if (eidPattern.Match(term).Success)
            {
                return Load(term).Tables[0];
            }
            else
            {
                var first = string.Empty;
                var last = string.Empty;
                if (term.IndexOf(",") > 0)
                {
                    var items = term.Split(',');
                    last = items[0].Trim();
                    first = items[1].Trim();
                }
                else if (term.IndexOf(" ") > 0)
                {
                    var items = term.Split(' ');
                    last = items[1].Trim();
                    first = items[0].Trim();
                }
                else
                {
                    last = term.Trim();
                }

                return DALControls.ControlsDB.CreateDB().ExecuteDataSet("lookupHR_Workers", last, first, includeAll).Tables[0];
            }
        }

        public static DataTable Lookup(string term)
        {
            return Lookup(term, false);
        }
    }
}
