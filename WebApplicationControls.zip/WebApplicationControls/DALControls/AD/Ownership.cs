﻿using System;

namespace DALControls.AD
{
    public static class Ownership
    {
        public static Guid Add(Guid objectGUID, string eid, int gearid, Guid ownerObjectGUID, string notes, string modifiedBy)
        {
            try
            {
                return (Guid)DALControls.ControlsDB.CreateDB().ExecuteScalar(
                    "AD_ObjectOwners_Add",
                    objectGUID,
                    (string.IsNullOrEmpty(eid)) ? null : eid,
                    gearid,
                    (ownerObjectGUID == Guid.Empty) ? null : (object)ownerObjectGUID,
                    notes,
                    modifiedBy);
            }
            catch
            {
                return Guid.Empty;
            }
        }

        public static System.Data.DataTable List(Guid objectGUID)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("AD_ObjectOwners_List", objectGUID).Tables[0];
        }

        public static void Delete(Guid guid, string notes, string ModifiedBy)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("AD_ObjectOwners_Delete", guid, notes, ModifiedBy);
        }
    }
}
