﻿using System;
using System.Data;

namespace DALControls.AD
{
    public static class Groups
    {
        public static DataSet ListAD_GroupMembersAll(Guid guid)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("ListAD_GroupMembersAll", guid);
        }

        public static System.Collections.Generic.IEnumerable<EntityControls.AD.ADObject> ListAD_GroupMembersAll(string domain, string samAccountName)
        {
            return from user in DALControls.ControlsDB.CreateDB().ExecuteDataSet("listAD_MembershipByNTID", domain, samAccountName).Tables[0].AsEnumerable()
                   select new EntityControls.AD.ADObject()
                   {
                       //objectGUID = user.Field<Guid>("objectGUID"),
                       Domain = user.Field<string>("GroupDomain"),
                       NTID = user.Field<string>("GroupName"),
                       //Description = user.Field<string>("Description"),
                       //DistinguishedName = user.Field<string>("distinguishedName"),

                   };
        }

        public static DataTable ListOrganizationalUnits(bool includeDisabled)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("listAD_OrganizationalUnitsWithGroupCount", includeDisabled).Tables[0];
        }


        public static System.Collections.Generic.IEnumerable<EntityControls.AD.Group> SearchUnderOU(string domain, System.Guid ouGuid, string searchTerm, bool includeEmpty)
        {
            domain = (string.IsNullOrEmpty(domain)) ? string.Empty : domain;
            searchTerm = (string.IsNullOrEmpty(searchTerm)) ? string.Empty : searchTerm;

            return from user in DALControls.ControlsDB.CreateDB().ExecuteDataSet("searchAD_GroupsUnderOU", domain, ouGuid, searchTerm, includeEmpty).Tables[0].AsEnumerable()
                   select new EntityControls.AD.Group()
                   {
                       objectGUID = user.Field<Guid>("objectGUID"),
                       Domain = user.Field<string>("Domain"),
                       NTID = user.Field<string>("SAMAccountName"),
                       Description = user.Field<string>("Description"),
                       DistinguishedName = user.Field<string>("distinguishedName"),
                       MemberGroups = user.IsNull("MemberGroups") ? 0 : user.Field<int>("MemberGroups"),
                       MemberUsers = user.IsNull("MemberUsers") ? 0 : user.Field<int>("MemberUsers"),
                   };
        }

        public static DataTable Lookup(string term)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("lookupAD_Groups", term).Tables[0];
        }

        public static Guid GetGUID(string fullGroupName)
        {
            var sql = string.Format("SELECT [objectGUID] FROM [Controls].[dbo].[View_AD_Groups] WHERE [FullName] = '{0}'", fullGroupName);

            try
            {
                return (Guid)ControlsDB.CreateDB().ExecuteScalar(CommandType.Text, sql);
            }
            catch
            {
                return Guid.Empty;
            }
        }
    }
}
