﻿using System.Linq;
using System.Data;
using System;
using System.Collections.Generic;

namespace DALControls.AD
{
    public static class Users
    {
        public static EntityControls.AD.User Load(string id)
        {
            var userID = new EntityControls.AD.ADObject(id);

            var users = from user in DALControls.ControlsDB.CreateDB().ExecuteDataSet("loadAD_User", userID.Domain, userID.NTID).Tables[0].AsEnumerable()
                        select new EntityControls.AD.User()
                        {
                            Combine = id,
                            Email = user.Field<string>("Email"),
                            DisplayName = user.Field<string>("DisplayName"),
                            LastName = user.Field<string>("LastName"),
                            FirstName = user.Field<string>("FirstName"),
                            EID = user.Field<string>("EID"),
                            IsDisabled = user.Field<bool>("IsActive"),
                            objectGUID = user.Field<Guid>("objectGUID")
                        };

            return users.FirstOrDefault();
        }

        public static System.Collections.Generic.IEnumerable<EntityControls.AD.User> Search(string domain, bool ownerlessOnly, string samAccountID, string eid, string email, string lastName, string firstName)
        {
            return from user in DALControls.ControlsDB.CreateDB().ExecuteDataSet("SearchAD_User", domain, samAccountID, eid, email, lastName, firstName).Tables[0].AsEnumerable()
                   select new EntityControls.AD.User()
                   {
                       Domain = user.Field<string>("Domain"),
                       NTID = user.Field<string>("NTID"),
                       Email = user.Field<string>("Email"),
                       DisplayName = user.Field<string>("DisplayName"),
                       LastName = user.Field<string>("LastName"),
                       FirstName = user.Field<string>("FirstName"),
                       EID = user.Field<string>("EID"),
                       IsDisabled = user.Field<bool>("IsActive")
                   };
        }


        public static DataSet ListMembershipByEID(string eid)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("listAD_MembershipByEID", eid);
        }

        public static DataTable ListUsersByEID(string eid)
        {
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("listAD_UsersByEID", eid).Tables[0];
        }

        public static DataTable ListAllCategories()
        {
            var sql = "SELECT distinct ISNULL([Category], 'Undefined') as Category FROM [Controls].[dbo].[AD_Users] order by 1";
            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListAllDomains()
        {
            var sql = "SELECT distinct [Domain] FROM [Controls].[dbo].[AD_Users] order by 1";
            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListAllOwnedBy(Guid ownerGUID)
        {
            var sql = @"SELECT View_AD_Users.Domain, View_AD_Users.sAMAccountName, View_AD_Users.Status, IsActive 
FROM Ownership.View_Objects INNER JOIN View_AD_Users ON Ownership.View_Objects.ObjectGUID = View_AD_Users.objectGUID 
WHERE Ownership.View_Objects.OwnerGUID='{0}' ORDER BY  1,2 ";
            return ControlsDB.ExecuteText(string.Format(sql, ownerGUID));
        }

        public static void SetCategory(Guid objectGUID, string value, string modifiedBy)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("AD_Users_SetCategory", objectGUID, value, modifiedBy);
        }
        public static void SetAccountType(Guid objectGUID, string value, string modifiedBy)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("AD_Users_SetAccountType", objectGUID, value, modifiedBy);
        }

        public static DataTable Search(string term, Guid ouGUID, string domain, bool includeDisabled, string sort, string sortDirection)
        {

            var sql = "SELECT Domain, sAMAccountName, DisplayName, Description, objectGUID, Category, EID, LastLogon,  (SELECT count(1) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [objectGUID]= View_AD_Users.objectGUID) AS Owners  FROM View_AD_Users";
            var queries = new HashSet<string>();

            if (!includeDisabled)
            {
                queries.Add("(IsActive = 1)");
            }

            if (ouGUID != Guid.Empty)
            {
                queries.Add(string.Format("(ouGUID = '{0}')", ouGUID));
            }

            if (!string.IsNullOrEmpty(term))
            {
                term = term.Trim();
                if (!string.IsNullOrEmpty(term))
                {
                    queries.Add(string.Format("(CHARINDEX('{0}',sAMAccountName, 1) > 0)", term));
                }
            }
            if (!string.IsNullOrEmpty(domain))
            {
                queries.Add(string.Format("(Domain = '{0}')", domain));
            }
            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }
            if (!string.IsNullOrEmpty(sort))
            {
                sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, sortDirection));
            }

            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListUsers(string sort, string order, string term, string domains, string categories, string statuses, string owners, string accountTypes)
        {
            var sql = "SELECT Domain, sAMAccountName, DisplayName, Description as Description, objectGUID, Category, AccountType, EID, LastLogon, Status,  (SELECT count(1) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [objectGUID]= View_AD_Users.objectGUID) AS Owners  FROM View_AD_Users";
            var queries = new HashSet<string>();

            //if (ouGUID != Guid.Empty) queries.Add(string.Format("(ouGUID = '{0}')", ouGUID));
            if (!string.IsNullOrEmpty(term)) queries.Add(string.Format("(CHARINDEX('{0}',sAMAccountName, 1) > 0)", term));
            if (!string.IsNullOrEmpty(domains)) queries.Add(string.Format("(Domain IN ({0}))", domains));
            if (!string.IsNullOrEmpty(accountTypes)) queries.Add(string.Format("(ISNULL(AccountType,'') IN ({0}))", accountTypes.Replace("Undefined", "")));
            if (!string.IsNullOrEmpty(categories))
            {
                if (categories.IndexOf("'Undefined'") > -1)
                {
                    if (categories.IndexOf("','") > -1)
                    {
                        queries.Add(string.Format("((Category IN ({0})) OR (Category IS NULL))", categories));
                    }
                    else
                    {
                        queries.Add(string.Format("(Category IS NULL)", categories));
                    }
                }
                else
                {
                    queries.Add(string.Format("(Category IN ({0}))", categories));
                }
            }

            if (!string.IsNullOrEmpty(statuses))
            {
                statuses = statuses.ToLower();
                if (statuses.IndexOf("all") < 0)
                {
                    var active = statuses.IndexOf("active") >= 0;
                    var disabled = statuses.IndexOf("disabled") >= 0;
                    var expired = statuses.IndexOf("expired") >= 0;

                    var subqueries = new HashSet<string>();
                    if (!(active && disabled && expired))
                    {
                        if (active) subqueries.Add(string.Format("(IsActive=1)"));
                        if (disabled) subqueries.Add(string.Format("(IsDisabled=1)"));
                        if (expired) subqueries.Add(string.Format("(IsExpired=1)"));

                        if (subqueries.Count > 0)
                        {
                            queries.Add(string.Format("({0})", string.Join(" OR ", subqueries.ToArray())));
                        }
                    }
                }

            }


            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }

            if (!string.IsNullOrEmpty(owners))
            {
                owners = owners.ToLower();
                var withoutOwner = owners == "all" || owners.IndexOf("without") >= 0;
                var withOwner = owners == "all" || owners.IndexOf("with ") >= 0;

                if (!(withoutOwner && withOwner))
                {
                    sql = string.Format("SELECT * FROM ({0}) F ", sql);
                    if (withOwner) sql = string.Format("{0} WHERE (Owners > 0)", sql);
                    if (withoutOwner) sql = string.Format("{0} WHERE (Owners = 0)", sql);

                }
            }


            if (!string.IsNullOrEmpty(sort))
            {
                sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));
            }

            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListOrganizationalUnits(string term, string categories, string statuses, string owners)
        {
            var sql = "SELECT ouGuid, (SELECT count(1) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [objectGUID]= View_AD_Users.objectGUID) AS Owners  FROM View_AD_Users";
            var queries = new HashSet<string>();

            if (!string.IsNullOrEmpty(term)) queries.Add(string.Format("(CHARINDEX('{0}',sAMAccountName, 1) > 0)", term));
            if (!string.IsNullOrEmpty(categories))
            {
                if (categories.IndexOf("'Undefined'") > -1)
                {
                    queries.Add(string.Format("((Category IN ({0})) OR (Category IS NULL))", categories));
                }
                else
                {
                    queries.Add(string.Format("(Category IN ({0}))", categories));
                }
            }

            if (!string.IsNullOrEmpty(statuses))
            {
                statuses = statuses.ToLower();
                if (statuses.IndexOf("all") < 0)
                {
                    var active = statuses.IndexOf("active") >= 0;
                    var disabled = statuses.IndexOf("disabled") >= 0;
                    var expired = statuses.IndexOf("expired") >= 0;

                    var subqueries = new HashSet<string>();
                    if (!(active && disabled && expired))
                    {
                        if (active) subqueries.Add(string.Format("(IsActive=1)"));
                        if (disabled) subqueries.Add(string.Format("(IsDisabled=1)"));
                        if (expired) subqueries.Add(string.Format("(IsExpired=1)"));

                        if (subqueries.Count > 0)
                        {
                            queries.Add(string.Format("({0})", string.Join(" OR ", subqueries.ToArray())));
                        }
                    }
                }

            }

            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }

            if (!string.IsNullOrEmpty(owners))
            {
                owners = owners.ToLower();
                var withoutOwner = owners == "all" || owners.IndexOf("without") >= 0;
                var withOwner = owners == "all" || owners.IndexOf("with ") >= 0;

                if (!(withoutOwner && withOwner))
                {
                    sql = string.Format("SELECT * FROM ({0}) F ", sql);
                    if (withOwner) sql = string.Format("{0} WHERE (Owners > 0)", sql);
                    if (withoutOwner) sql = string.Format("{0} WHERE (Owners = 0)", sql);

                }
            }

            sql = string.Format("SELECT ouGuid, COUNT(1) FROM ({0}) T GROUP BY ouGuid", sql);
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet("listAD_OrganizationalUnitsWithUserCount", sql).Tables[0];
        }


    }
}
