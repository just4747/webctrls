﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DALControls.Termination
{
    public static class ThisWeek
    {
        public static System.Data.DataSet List()
        {
            return ControlsDB.CreateDB().ExecuteDataSet("listWorkersTerminatedThisWeek");
        }
    }
}
