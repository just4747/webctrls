﻿using System;
using System.Data;
namespace DALControls.Termination
{
    public static class HrTerminationFile
    {

        public static DateTime LastImported()
        {
            return (DateTime)ControlsDB.CreateDB().ExecuteScalar(CommandType.Text, "SELECT MAX([CreatedOn]) FROM [Controls].[dbo].[HR_Terminations]");
        }
    }
}
