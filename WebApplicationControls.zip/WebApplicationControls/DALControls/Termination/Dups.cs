﻿
namespace DALControls.Termination
{
    public static class Dups
    {
        public static System.Data.DataSet List()
        {
            return ControlsDB.CreateDB().ExecuteDataSet("listDuplicateWorkersTerminatedThisWeek");
            //return ControlsDB.CreateDB().ExecuteDataSet("listDuplicateWorkersTerminatedLastWeek");

        }

        public static void Update(System.Guid guid, int state, string modifiedBy)
        {
            ControlsDB.CreateDB().ExecuteNonQuery("EIDPairs_update", guid, state, modifiedBy);
        }
    }
}
