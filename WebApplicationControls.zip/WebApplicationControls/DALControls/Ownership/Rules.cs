﻿
namespace DALControls.Ownership
{
    public static class Rules
    {
        public static System.Data.DataTable Load(string objectType)
        {
            var sql = string.Format("SELECT [OwnerType],[OwnedBy],[ManagedBy] FROM [Ownership].[Rules] WHERE [ObjectType]='{0}'", objectType);
            return DALControls.ControlsDB.ExecuteText(sql);
        }
    }
}
