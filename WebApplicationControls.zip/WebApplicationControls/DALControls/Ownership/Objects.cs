﻿using System;
using System.Data;

namespace DALControls.Ownership
{
    public static class Objects
    {
        public static Guid Add(Guid objectGUID, Guid ownerGUID, string ownOrManage, string notes, string ModifiedBy)
        {
            return (Guid)ControlsDB.CreateDB().ExecuteScalar("ObjectOwners_Add", objectGUID, ownerGUID, ownOrManage, notes, ModifiedBy);
        }

        public static System.Data.DataTable List(Guid objectGUID)
        {
            return ControlsDB.CreateDB().ExecuteDataSet("listObject_Owners", objectGUID).Tables[0];
        }

        public static void Delete(Guid ownershipGUID, string notes, string ModifiedBy)
        {
            ControlsDB.CreateDB().ExecuteScalar("ObjectOwners_Delete", ownershipGUID, notes, ModifiedBy);
        }

        public static void Confirm(Guid ownershipGUID, string notes, string ModifiedBy)
        {
            ControlsDB.CreateDB().ExecuteScalar("ObjectOwners_Confirm", ownershipGUID, notes, ModifiedBy);
        }

        public static DataTable ListADAccountsOwnedBy(Guid ownerGUID)
        {
            var sql = string.Format(@"
	SELECT        
		View_AD_Users.Domain, 
		View_AD_Users.sAMAccountName, 
		View_AD_Users.objectGUID,
        View_AD_Users.lastLogon,
		View_AD_Groups.Domain AS GroupDomain, 
		View_AD_Groups.name AS GroupName,
		View_AD_Groups.objectGUID AS GroupObjectGUID
	FROM            
		View_AD_GroupMemberUsers INNER JOIN
		View_AD_Groups ON View_AD_GroupMemberUsers.groupGUID = View_AD_Groups.objectGUID RIGHT OUTER JOIN
		View_AD_Users ON View_AD_GroupMemberUsers.memberGUID = View_AD_Users.objectGUID INNER JOIN 
		 Ownership.View_Objects ON Ownership.View_Objects.ObjectGUID = View_AD_Users.objectGUID
	WHERE        
		(Ownership.View_Objects.OwnerGUID = '{0}')
	ORDER BY
		View_AD_Users.Domain, 
		View_AD_Users.sAMAccountName, 
		View_AD_Groups.Domain, 
		View_AD_Groups.name", ownerGUID);
            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListORACLEAccountsOwnedBy(Guid ownerGUID)
        {
            var sql = string.Format(@"
	SELECT        
		View_ORACLE_DBA_USERS.DatabaseName, 
		View_ORACLE_DBA_USERS.USERNAME, 
		View_ORACLE_DBA_USERS.objectGUID,
		View_ORACLE_DBA_ROLES.ROLENAME,
		View_ORACLE_DBA_ROLES.objectGUID AS RoleObjectGUID
	FROM
		View_ORACLE_DBA_ROLES INNER JOIN 
		View_ORACLE_DBA_ROLE_PRIVS ON View_ORACLE_DBA_ROLE_PRIVS.DatabaseName = View_ORACLE_DBA_ROLES.DatabaseName AND View_ORACLE_DBA_ROLE_PRIVS.[GRANTED_ROLE] = View_ORACLE_DBA_ROLES.ROLENAME  RIGHT OUTER JOIN
		View_ORACLE_DBA_USERS ON View_ORACLE_DBA_ROLE_PRIVS.DatabaseName = View_ORACLE_DBA_USERS.DatabaseName AND View_ORACLE_DBA_ROLE_PRIVS.[GRANTEE] = View_ORACLE_DBA_USERS.USERNAME INNER JOIN 
		 Ownership.View_Objects ON Ownership.View_Objects.ObjectGUID = View_ORACLE_DBA_USERS.objectGUID
	WHERE        
		(Ownership.View_Objects.OwnerGUID = '{0}')
	ORDER BY
		View_ORACLE_DBA_USERS.DatabaseName, 
		View_ORACLE_DBA_USERS.USERNAME, 
		View_ORACLE_DBA_ROLES.ROLENAME", ownerGUID);
            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListSQLSERVERAccountsOwnedBy(Guid ownerGUID)
        {
            var sql = string.Format(@"
	SELECT        
		View_ORACLE_DBA_USERS.DatabaseName, 
		View_ORACLE_DBA_USERS.USERNAME, 
		View_ORACLE_DBA_USERS.objectGUID,
		View_ORACLE_DBA_ROLES.ROLENAME,
		View_ORACLE_DBA_ROLES.objectGUID AS RoleObjectGUID
	FROM
		View_ORACLE_DBA_ROLES INNER JOIN 
		View_ORACLE_DBA_ROLE_PRIVS ON View_ORACLE_DBA_ROLE_PRIVS.DatabaseName = View_ORACLE_DBA_ROLES.DatabaseName AND View_ORACLE_DBA_ROLE_PRIVS.[GRANTED_ROLE] = View_ORACLE_DBA_ROLES.ROLENAME  RIGHT OUTER JOIN
		View_ORACLE_DBA_USERS ON View_ORACLE_DBA_ROLE_PRIVS.DatabaseName = View_ORACLE_DBA_USERS.DatabaseName AND View_ORACLE_DBA_ROLE_PRIVS.[GRANTEE] = View_ORACLE_DBA_USERS.USERNAME INNER JOIN 
		 Ownership.View_Objects ON Ownership.View_Objects.ObjectGUID = View_ORACLE_DBA_USERS.objectGUID
	WHERE        
		(Ownership.View_Objects.OwnerGUID = '{0}')
	ORDER BY
		View_ORACLE_DBA_USERS.DatabaseName, 
		View_ORACLE_DBA_USERS.USERNAME, 
		View_ORACLE_DBA_ROLES.ROLENAME", ownerGUID);
            return ControlsDB.ExecuteText(sql);
        }
    }
}
