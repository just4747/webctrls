﻿using System;
using System.Data;

namespace DALControls.CAL
{
    public static class Applications
    {
        public static DataTable ListApplicationAccountsOwnedBy(Guid ownerGUID)
        {
            var sql = string.Format(@"
SELECT       View_GEAR_Applications.Name AS ApplicationName, View_CAL_ApplicationUsers.ApplicationLoginID, 
                         View_CAL_ApplicationUsers.RoleName
FROM            View_CAL_ApplicationUsers INNER JOIN
                         View_GEAR_Applications ON View_CAL_ApplicationUsers.GEARID = View_GEAR_Applications.GEARID INNER JOIN
                         View_WorkersAll ON View_CAL_ApplicationUsers.EID = View_WorkersAll.EID
WHERE        (View_WorkersAll.ObjectGUID ='{0}')
ORDER BY ApplicationName, View_CAL_ApplicationUsers.ApplicationLoginID", ownerGUID);

// RWCabral: AID Transition
//            var sql = string.Format(@"
//SELECT        ISNULL(View_GEAR_Applications.Name, View_CAL_Applications.Name) AS ApplicationName, View_CAL_ApplicationUsers.ApplicationLoginID, 
//                         View_CAL_ApplicationUsers.RoleName
//FROM            View_CAL_ApplicationUsers INNER JOIN
//                         View_CAL_Applications ON View_CAL_ApplicationUsers.AID = View_CAL_Applications.AID INNER JOIN
//                         View_GEAR_Applications ON View_CAL_Applications.GEARID = View_GEAR_Applications.GEARID INNER JOIN
//                         View_WorkersAll ON View_CAL_ApplicationUsers.EID = View_WorkersAll.EID
//WHERE        (View_WorkersAll.ObjectGUID ='{0}')
//ORDER BY ApplicationName, View_CAL_ApplicationUsers.ApplicationLoginID", ownerGUID);

            return ControlsDB.ExecuteText(sql);
        }

    }
}
