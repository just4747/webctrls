﻿using System.Collections.Generic;
using System.Linq;
using System.Data;
using System;
namespace DALControls.ORACLE
{
    public class User
    {
        public static DataTable ListUsers(string sort, string order, string term, string database, string profile, string status, string owners, string accountTypes)
        {
            var sql = @"SELECT *
,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [ModifiedBy] <> 'System' AND [objectGUID]= View_ORACLE_DBA_USERS.objectGUID) AS ConfirmedOwners
,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [ModifiedBy] = 'System' AND [objectGUID]= View_ORACLE_DBA_USERS.objectGUID) AS UnconfirmedOwners FROM [View_ORACLE_DBA_USERS]";
            var queries = new HashSet<string>();
            queries.Add("[IsDeleted] = 0");
            if (!string.IsNullOrEmpty(term)) queries.Add(string.Format("([USERNAME] like '%{0}%')", term));
            if (!string.IsNullOrEmpty(database)) queries.Add(string.Format("([DatabaseName] in ({0}))", database));
            if (!string.IsNullOrEmpty(status)) queries.Add(string.Format("([ACCOUNT_STATUS] in ({0}))", status));
            if (!string.IsNullOrEmpty(profile)) queries.Add(string.Format("([PROFILE] in ({0}))", profile));
            if (!string.IsNullOrEmpty(accountTypes)) queries.Add(string.Format("(ISNULL(AccountType,'') IN ({0}))", accountTypes.Replace("Undefined", "")));

            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }

            sql = string.Format("SELECT *, ConfirmedOwners + UnconfirmedOwners as Owners FROM ({0}) F ", sql);
            if (!string.IsNullOrEmpty(owners))
            {
                var withoutOwner = owners == "All" || owners.IndexOf("'without'") >= 0;
                var withUnconfirmedOwner = owners == "All" || owners.IndexOf("'WithUnconfirmed'") >= 0;
                var withOwner = owners == "All" || owners.IndexOf("'with'") >= 0;

                if ((withoutOwner | withOwner | withUnconfirmedOwner) && (!(withoutOwner & withOwner & withUnconfirmedOwner)))
                {
                    var subqueries = new HashSet<string>();
                    if (withOwner) subqueries.Add("(ConfirmedOwners > 0)");
                    if (withUnconfirmedOwner) subqueries.Add("(UnconfirmedOwners > 0)"); 
                    if (withoutOwner) subqueries.Add("(ConfirmedOwners + UnconfirmedOwners = 0)");  

                    if (subqueries.Count > 0)
                    {
                        sql = string.Concat(sql, " WHERE ", string.Join(" OR ", subqueries.ToArray()));
                    }
                }
            }
            if (!string.IsNullOrEmpty(sort)) sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));


            return DALControls.ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListProfiles()
        {
            var sql = "SELECT DISTINCT [PROFILE] FROM [View_ORACLE_DBA_USERS] ORDER BY 1";
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql).Tables[0];
        }

        public static DataTable ListStatuses()
        {
            var sql = "SELECT DISTINCT [ACCOUNT_STATUS] FROM [View_ORACLE_DBA_USERS] ORDER BY 1";
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql).Tables[0];
        }

        public static DataTable ListDatabases()
        {
            var sql = "SELECT DISTINCT [DatabaseName] FROM [View_ORACLE_DBA_USERS] ORDER BY 1";
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql).Tables[0];
        }

        public static DataTable ListMembershipRoles(string DatabaseName, string USERNAME)
        {
            var sql = "SELECT [GRANTED_ROLE] FROM [Controls].[dbo].[ORACLE_DBA_ROLE_PRIVS] WHERE [IsDeleted] = 0 AND [DatabaseName] = '{0}' AND [GRANTEE] = '{1}' ORDER BY 1";
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, string.Format(sql, DatabaseName, USERNAME)).Tables[0];
        }

        public static void SetAccountType(Guid objectGUID, string value, string modifiedBy)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("ORACLE_DBA_Users_SetAccountType", objectGUID, value, modifiedBy);
        }

    }
}
