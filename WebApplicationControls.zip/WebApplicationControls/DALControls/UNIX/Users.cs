﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Specialized;
using System.Data;
namespace DALControls.UNIX
{
    public static class Users
    {
        public static DataSet ListUsers(bool includeFilter, string[] FilterColumns, string sort, string order, string term, string hostname, string owners, string shell, string accountTypes)
        {
            var sql = ListUsersSQL(sort, order, term, hostname, owners, shell, accountTypes);

            if (includeFilter)
            {
                var sqls = new HashSet<string>();
                foreach (var column in FilterColumns)
                {
                    sqls.Add(ListOptions(column, term, hostname, owners, shell, accountTypes));
                }

                sql = string.Format("{0}; {1} ORDER BY 1, 2;", sql, string.Join(" UNION ", sqls.ToArray()));
            }

            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql);
        }

        private static string ListOptions(string column, string term, string hostname, string owners, string shell, string accountTypes)
        {
            var sql = @"SELECT *
,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [ModifiedBy] <> 'System' AND [objectGUID]= [View_UNIX_Users].objectGUID) AS ConfirmedOwners
,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [ModifiedBy] = 'System' AND [objectGUID]= [View_UNIX_Users].objectGUID) AS UnconfirmedOwners
FROM [Controls].[dbo].[View_UNIX_Users]";

            var queries = new HashSet<string>();
            if (!string.IsNullOrEmpty(term))
                if (term.IndexOf('%') >= 0 || term.IndexOf('_') >= 0)
                {
                    queries.Add(string.Format("(([Username] like '{0}') OR ([Comment] like '{0}'))", term));
                }
                else
                {
                    queries.Add(string.Format("([Username] = '{0}')", term));
                }
            if (!string.IsNullOrEmpty(hostname) && column != "hostname") queries.Add(string.Format("([hostname] in ({0}))", hostname));
            if (!string.IsNullOrEmpty(shell) && column != "shell") queries.Add(string.Format("(ISNULL([shell],'NULL') in ({0}))", shell));
            if (!string.IsNullOrEmpty(accountTypes) && column != "accountType") queries.Add(string.Format("(ISNULL(AccountType,'NULL') IN ({0}))", accountTypes.Replace("Undefined", "")));
            if (queries.Count > 0) sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));

            sql = string.Format("SELECT *, ConfirmedOwners + UnconfirmedOwners as TotalOwners, CASE ConfirmedOwners WHEN 0 THEN CASE UnconfirmedOwners WHEN 0 THEN 'Without' ELSE 'With Unconfirmed' END ELSE 'With Confirmed' END as Owners FROM ({0}) F ", sql);
            if (!string.IsNullOrEmpty(owners) && column != "owners")
            {
                var subqueries = new HashSet<string>();
                if (owners.IndexOf("'Without'") >= 0) subqueries.Add("(ConfirmedOwners + UnconfirmedOwners = 0)");
                if (owners.IndexOf("'With Unconfirmed'") >= 0) subqueries.Add("(UnconfirmedOwners > 0)");
                if (owners.IndexOf("'With Confirmed'") >= 0) subqueries.Add("(ConfirmedOwners > 0)");
                if (subqueries.Count > 0) sql = string.Concat(sql, " WHERE ", string.Join(" OR ", subqueries.ToArray()));
            }

            sql = string.Format("SELECT '{0}' as Name, ISNULL({0},'NULL') as Value, COUNT(1) AS [Count] FROM ({1}) T GROUP BY {0}", column, sql);
            return sql;

        }

        private static string ListUsersSQL(string sort, string order, string term, string hostname, string owners, string shell, string accountTypes)
        {
            var sql = @"SELECT *
,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [ModifiedBy] <> 'System' AND [objectGUID]= [View_UNIX_Users].objectGUID) AS ConfirmedOwners
,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [ModifiedBy] = 'System' AND [objectGUID]= [View_UNIX_Users].objectGUID) AS UnconfirmedOwners
FROM [Controls].[dbo].[View_UNIX_Users]";

            var queries = new HashSet<string>();
            if (!string.IsNullOrEmpty(term))
                if (term.IndexOf('%') >= 0 || term.IndexOf('_') >= 0)
                {
                    queries.Add(string.Format("(([Username] like '{0}') OR ([Comment] like '{0}'))", term));
                }
                else
                {
                    queries.Add(string.Format("([Username] = '{0}')", term));
                }
            if (!string.IsNullOrEmpty(hostname)) queries.Add(string.Format("([hostname] in ({0}))", hostname));
            if (!string.IsNullOrEmpty(shell)) queries.Add(string.Format("(ISNULL([shell],'NULL') in ({0}))", shell));
            if (!string.IsNullOrEmpty(accountTypes)) queries.Add(string.Format("(ISNULL(AccountType,'NULL') IN ({0}))", accountTypes.Replace("Undefined", "")));
            if (queries.Count > 0) sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));

            sql = string.Format("SELECT *, ConfirmedOwners + UnconfirmedOwners as Owners FROM ({0}) F ", sql);
            if (!string.IsNullOrEmpty(owners))
            {
                var subqueries = new HashSet<string>();
                if (owners.IndexOf("'Without'") >= 0) subqueries.Add("(ConfirmedOwners + UnconfirmedOwners = 0)");
                if (owners.IndexOf("'With Unconfirmed'") >= 0) subqueries.Add("(UnconfirmedOwners > 0)");
                if (owners.IndexOf("'With Confirmed'") >= 0) subqueries.Add("(ConfirmedOwners > 0)");
                if (subqueries.Count > 0) sql = string.Concat(sql, " WHERE ", string.Join(" OR ", subqueries.ToArray()));
            }

            if (!string.IsNullOrEmpty(sort)) sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));
            return sql;
        }

        public static void SetAccountType(Guid objectGUID, string value, string modifiedBy)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("UNIX_Users_SetAccountType", objectGUID, value, modifiedBy);
        }
    }
}
