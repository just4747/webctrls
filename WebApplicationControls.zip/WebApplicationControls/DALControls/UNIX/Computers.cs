﻿using System;
using System.Data;


namespace DALControls.UNIX
{
    public static class Computers
    {
        public static DataTable ListUNIXAccountsOwnedBy(Guid ownerGUID)
        {
            var sql = string.Format(@"
SELECT        View_UNIX_Users.Hostname, View_UNIX_Users.Username, View_UNIX_GroupMembers.Groupname
FROM            View_WorkersAll INNER JOIN
                         Ownership.View_Objects ON View_WorkersAll.ObjectGUID = Ownership.View_Objects.OwnerGUID INNER JOIN
                         View_UNIX_Users ON Ownership.View_Objects.ObjectGUID = View_UNIX_Users.objectGUID INNER JOIN
                         View_UNIX_GroupMembers ON View_UNIX_Users.Hostname = View_UNIX_GroupMembers.Hostname AND 
                         View_UNIX_Users.Username = View_UNIX_GroupMembers.Username
WHERE        (View_WorkersAll.objectGUID = '{0}')", ownerGUID);
            return ControlsDB.ExecuteText(sql);
        }
    }
}
