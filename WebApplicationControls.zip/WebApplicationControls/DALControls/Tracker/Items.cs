﻿using System.Data;

namespace DALControls.Tracker
{
    public static class Items
    {
        public static DataTable ListByAID(string aid)
        {
            var sql = @"SELECT [ID]
      ,[AID]
      ,[Applicationname]
      ,[RecertType]
      ,[LastName]
      ,[FirstName]
      ,[EMailAddress_Other]
      ,[Logon_User_AccountID_Group]
      ,[Description]
      ,[FullName]
      ,[Recertifiers]
      ,[RecertOwner]
      ,[Notes]
      ,[EMailNotificationNumber1]
      ,[EMailNotificationNumber2]
      ,[EMailNotificationNumber3]
      ,[ISSUERECERTSTATUS]
      ,[ResponseReceived]
      ,[Accept_Reject]
      ,[SubmitDeletionRequestNumber1]
      ,[SubmitDeletionRequestNumber2]
      ,[DeletionsConfirmed]
      ,[StatusFinal]
      ,[TicketNumber]
      ,[QAFinalReview]
  FROM [Project].[Tracker]
WHERE AID='{0}'
";

            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, string.Format(sql, aid)).Tables[0];
        }

        public static void Save(int ID, System.DateTime EMailNotificationNumber1, System.DateTime EMailNotificationNumber2, System.DateTime EMailNotificationNumber3, System.DateTime ResponseReceived, string Accept_Reject, System.DateTime SubmitDeletionRequestNumber1, System.DateTime SubmitDeletionRequestNumber2, System.DateTime DeletionsConfirmed, string StatusFinal, string TicketNumber, System.DateTime QAFinalReview)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("Tracker_Update",
                ID,
                EMailNotificationNumber1,
                EMailNotificationNumber2,
                EMailNotificationNumber3,
                ResponseReceived,
                Accept_Reject,
                SubmitDeletionRequestNumber1,
                SubmitDeletionRequestNumber2,
                DeletionsConfirmed,
                StatusFinal,
                TicketNumber,
                QAFinalReview);
        }
    }
}
