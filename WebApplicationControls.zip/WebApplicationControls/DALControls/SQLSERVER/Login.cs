﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
namespace DALControls.SQLSERVER
{
    public static class Login
    {
        public static DataTable ListInstances()
        {
            var sql = "SELECT DISTINCT [InstanceName] FROM [View_SQLSERVER_server_Logins] ORDER BY 1";
            return DALControls.ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListStatuses()
        {
            var sql = "SELECT DISTINCT [Status] FROM [View_SQLSERVER_server_Logins] ORDER BY 1";
            return DALControls.ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListLoginTypes()
        {
            var sql = "SELECT DISTINCT [LoginType] FROM [View_SQLSERVER_server_Logins] ORDER BY 1";
            return DALControls.ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListLogins(string sort, string order, string term, string instance, string status, string owners, string loginType, string accountTypes)
        {

            var sql = @"SELECT * ,(SELECT ISNULL(count(1),0) FROM [Ownership].[Objects] WHERE [IsDeleted]=0 AND [objectGUID]= [View_SQLSERVER_server_Logins].objectGUID) AS Owners FROM [View_SQLSERVER_server_Logins]";
            var queries = new HashSet<string>();
            if (!string.IsNullOrEmpty(term)) queries.Add(string.Format("([LoginName] like '%{0}%')", term));
            if (!string.IsNullOrEmpty(instance)) queries.Add(string.Format("([InstanceName] in ({0}))", instance));
            if (!string.IsNullOrEmpty(status)) queries.Add(string.Format("([Status] in ({0}))", status));
            if (!string.IsNullOrEmpty(loginType)) queries.Add(string.Format("([LoginType] in ({0}))", loginType));
            //if (!string.IsNullOrEmpty(accountTypes)) queries.Add(string.Format("((LoginType <> 'SQL_LOGIN') OR ([AccountType] in ({0})))", accountTypes));
            if (!string.IsNullOrEmpty(accountTypes)) queries.Add(string.Format("(ISNULL(AccountType,'') IN ({0}))", accountTypes.Replace("Undefined", "")));


            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }

            sql = string.Format("SELECT * FROM ({0}) F ", sql);
            if (!string.IsNullOrEmpty(owners))
            {
                var withoutOwner = owners == "All" || owners.IndexOf("'without'") >= 0;
                var withOwner = owners == "All" || owners.IndexOf("'with'") >= 0;

                if ((withoutOwner | withOwner) && (!(withoutOwner & withOwner)))
                {
                    var subqueries = new HashSet<string>();
                    if (withOwner) subqueries.Add("(Owners > 0)");
                    if (withoutOwner) subqueries.Add("(Owners = 0)");

                    if (subqueries.Count > 0)
                    {
                        sql = string.Concat(sql, " WHERE ", string.Join(" OR ", subqueries.ToArray()));
                    }
                }
            }
            if (!string.IsNullOrEmpty(sort)) sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));


            return ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListLoginAndRoles(System.Guid objectGUID)
        {
            var sql = @"SELECT 
	View_SQLSERVER_server_Logins.InstanceName, 
    View_SQLSERVER_server_RoleMembers.RoleName
FROM            
    View_SQLSERVER_server_Logins LEFT OUTER JOIN
    View_SQLSERVER_server_RoleMembers ON 
    View_SQLSERVER_server_Logins.InstanceName = View_SQLSERVER_server_RoleMembers.InstanceName AND 
    View_SQLSERVER_server_Logins.LoginName = View_SQLSERVER_server_RoleMembers.LoginName
WHERE        
	(View_SQLSERVER_server_Logins.objectGUID = '{0}')
ORDER By 1,2";
            return ControlsDB.ExecuteText(string.Format(sql, objectGUID));
        }


        public static DataTable ListUserAndRoles(System.Guid objectGUID)
        {
            var sql = @"SELECT View_SQLSERVER_Database_Users.DatabaseName, 
                         View_SQLSERVER_Database_RoleMembers.RoleName
FROM            View_SQLSERVER_Database_Users INNER JOIN
                         View_SQLSERVER_server_Logins ON View_SQLSERVER_Database_Users.InstanceName = View_SQLSERVER_server_Logins.InstanceName AND 
                         View_SQLSERVER_Database_Users.name = View_SQLSERVER_server_Logins.LoginName LEFT OUTER JOIN
                         View_SQLSERVER_Database_RoleMembers ON 
                         View_SQLSERVER_Database_Users.InstanceName = View_SQLSERVER_Database_RoleMembers.InstanceName AND 
                         View_SQLSERVER_Database_Users.database_id = View_SQLSERVER_Database_RoleMembers.database_id AND 
                         View_SQLSERVER_Database_Users.name = View_SQLSERVER_Database_RoleMembers.UserName
WHERE        (View_SQLSERVER_server_Logins.objectGUID = '{0}')
ORDER By 1,2";
            return ControlsDB.ExecuteText(string.Format(sql, objectGUID));
        }

        public static void SetAccountType(System.Guid objectGUID, string value, string modifiedBy)
        {
            DALControls.ControlsDB.CreateDB().ExecuteNonQuery("SQLSERVER_Server_Logins_SetAccountType", objectGUID, value, modifiedBy);
        }
    }
}
