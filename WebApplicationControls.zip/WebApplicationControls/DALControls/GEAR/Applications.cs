﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace DALControls.GEAR
{
    public class Applications
    {
        public static IEnumerable<EntityControls.GEAR.Application> Search(string searchTerm, bool includeAll)
        {
            searchTerm = (string.IsNullOrEmpty(searchTerm)) ? string.Empty : searchTerm;

            return from application in DALControls.ControlsDB.CreateDB().ExecuteDataSet("searchGEAR_Applications", searchTerm, includeAll).Tables[0].AsEnumerable()
                   select new EntityControls.GEAR.Application()
                   {
                       GEARID = application.Field<int>("GEARID"),
                       Name = application.IsNull("Name") ? string.Empty : application.Field<string>("Name"),
                       Type = application.IsNull("Type") ? string.Empty : application.Field<string>("Type"),
                       IsActive = application.Field<bool>("IsActive"),
                       BU = application.IsNull("BU") ? string.Empty : application.Field<string>("BU"),
                       BIO = application.IsNull("BIO") ? string.Empty : application.Field<string>("BIO"),
                       State = application.IsNull("State") ? string.Empty : application.Field<string>("State"),
                       Description = application.IsNull("Description") ? string.Empty : application.Field<string>("Description"),
                   };
        }

        public static DataTable Lookup(string term)
        {
            int gearid = 0;

            if (int.TryParse(term, out gearid))
            {
                return DALControls.ControlsDB.CreateDB().ExecuteDataSet("loadGEAR_Application", gearid).Tables[0];

            }
            else
            {
                return DALControls.ControlsDB.CreateDB().ExecuteDataSet("lookupGEAR_Applications", term, false).Tables[0];
            }
        }

        public static DataTable ListBusinessUnites()
        {
            var sql = "SELECT DISTINCT [BU] FROM [GEAR_Applications] ORDER BY 1";
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql).Tables[0];
        }
        public static DataTable ListCurrentStates()
        {
            var sql = "SELECT DISTINCT [Current State] AS CurrentState FROM [Controls].[dbo].[GEAR_Applications] ORDER BY 1";
            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql).Tables[0];
        }

        public static DataTable ListApplications(string sort, string order, string term, string bu, string currentStates)
        {
            var sql = @"SELECT [Global App ID] as GlobalAppID, [Application name] AS Applicationname, BU, BIO, Portfolio, [Portfolio owners] AS Portfolioowners, [Current State] AS CurrentState, [Application Description] AS ApplicationDescription, [Access Certification - Tool or Process] AS AccessCertification_ToolorProcess, [Application owners] AS Applicationowners, [Business owners] AS Businessowners, ObjectGUID FROM GEAR_Applications";
            var queries = new HashSet<string>();
            queries.Add("[IsDeleted] = 0");
            if (!string.IsNullOrEmpty(term))
            {
                var id = 0;
                if (int.TryParse(term, out id))
                {
                    queries.Add(string.Format("([Global App ID] = {0})", id));
                }
                else
                {
                    queries.Add(string.Format("([Application name] like '%{0}%')", term));
                }
            }
            if (!string.IsNullOrEmpty(bu)) queries.Add(string.Format("([BU] in ({0}))", bu));
            if (!string.IsNullOrEmpty(currentStates)) queries.Add(string.Format("([Current State] in ({0}))", currentStates));
            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }

            if (!string.IsNullOrEmpty(sort)) sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));


            return DALControls.ControlsDB.ExecuteText(sql);
        }

        public static DataTable ListApplications(string sort, string order, Guid ObjectGUID)
        {
            var sql = @"SELECT View_GEAR_Applications.ObjectGUID, CAL_ApplicationUsers.ApplicationLoginID, ISNULL(View_WorkersAll.DisplayName, CAL_ApplicationUsers.LastName + ', ' + CAL_ApplicationUsers.FirstName) AS DisplayName, CAL_ApplicationUsers.RoleName 
FROM            CAL_ApplicationUsers INNER JOIN
                         View_GEAR_Applications ON CAL_ApplicationUsers.[GEAR ID] = View_GEAR_Applications.GEARID LEFT OUTER JOIN
                         View_WorkersAll ON CAL_ApplicationUsers.EID = View_WorkersAll.EID 
WHERE (CAL_ApplicationUsers.IsDeleted = 0) AND (View_GEAR_Applications.ObjectGUID = '{0}')
";
// RWCabral: AID Transition
//            var sql = @"SELECT        View_CAL_Applications.ObjectGUID, View_CAL_ApplicationUsers.ApplicationLoginID, ISNULL(View_WorkersAll.DisplayName,View_CAL_ApplicationUsers.DisplayName) AS DisplayName , View_CAL_ApplicationUsers.RoleName
//FROM            View_CAL_Applications INNER JOIN
//                         View_CAL_ApplicationUsers ON View_CAL_Applications.AID = View_CAL_ApplicationUsers.AID LEFT OUTER JOIN
//                         View_WorkersAll ON View_CAL_ApplicationUsers.EID = View_WorkersAll.EID
//WHERE        (View_CAL_Applications.ObjectGUID = '{0}')
//";
            
            if (!string.IsNullOrEmpty(sort)) sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));
            return DALControls.ControlsDB.ExecuteText(string.Format(sql, ObjectGUID));
        }

        public static DataSet ListApplications(bool includeFilter, string[] FilterColumns, string sort, string order, string term, string BU, string CurrentState)
        {
            var sql = ListApplicationsSQL(sort, order, term, BU, CurrentState);

            if (includeFilter)
            {
                var sqls = new HashSet<string>();
                foreach (var column in FilterColumns)
                {
                    sqls.Add(ListOptions(column, term,BU, CurrentState));
                }

                sql = string.Format("{0}; {1} ORDER BY 1, 2;", sql, string.Join(" UNION ", sqls.ToArray()));
            }

            return DALControls.ControlsDB.CreateDB().ExecuteDataSet(CommandType.Text, sql);
        }

        private static string ListOptions(string column, string term, string BU, string CurrentState)
        {
            var sql = @"SELECT [Global App ID] as GlobalAppID, [Application name] AS Applicationname, BU, BIO, Portfolio, [Portfolio owners] AS Portfolioowners, [Current State] AS CurrentState, [Application Description] AS ApplicationDescription, [Access Certification - Tool or Process] AS AccessCertification_ToolorProcess, [Application owners] AS Applicationowners, [Business owners] AS Businessowners, ObjectGUID FROM GEAR_Applications";
            var queries = new HashSet<string>();
            queries.Add("[IsDeleted] = 0");
            if (!string.IsNullOrEmpty(term))
            {
                var id = 0;
                if (int.TryParse(term, out id))
                {
                    queries.Add(string.Format("([Global App ID] = {0})", id));
                }
                else
                {
                    queries.Add(string.Format("([Application name] like '%{0}%')", term));
                }
            }
            if (!string.IsNullOrEmpty(BU) && column != "BU") queries.Add(string.Format("([BU] in ({0}))", BU));
            if (!string.IsNullOrEmpty(CurrentState) && column != "CurrentState") queries.Add(string.Format("([Current State] in ({0}))", CurrentState));
            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }



            sql = string.Format("SELECT '{0}' as Name, ISNULL({0},'NULL') as Value, COUNT(1) AS [Count] FROM ({1}) T GROUP BY {0}", column, sql);
            return sql;

        }

        private static string ListApplicationsSQL(string sort, string order, string term, string BU, string CurrentState)
        {
            var sql = @"SELECT [Global App ID] as GlobalAppID, [Application name] AS Applicationname, BU, BIO, Portfolio, [Portfolio owners] AS Portfolioowners, [Current State] AS CurrentState, [Application Description] AS ApplicationDescription, [Access Certification - Tool or Process] AS AccessCertification_ToolorProcess, [Application owners] AS Applicationowners, [Business owners] AS Businessowners, ObjectGUID FROM GEAR_Applications";
            var queries = new HashSet<string>();
            queries.Add("[IsDeleted] = 0");
            if (!string.IsNullOrEmpty(term))
            {
                var id = 0;
                if (int.TryParse(term, out id))
                {
                    queries.Add(string.Format("([Global App ID] = {0})", id));
                }
                else
                {
                    queries.Add(string.Format("([Application name] like '%{0}%')", term));
                }
            }
            if (!string.IsNullOrEmpty(BU)) queries.Add(string.Format("([BU] in ({0}))", BU));
            if (!string.IsNullOrEmpty(CurrentState)) queries.Add(string.Format("([Current State] in ({0}))", CurrentState));
            if (queries.Count > 0)
            {
                sql = string.Concat(sql, " WHERE ", string.Join(" AND ", queries.ToArray()));
            }

            if (!string.IsNullOrEmpty(sort)) sql = string.Concat(sql, string.Format(" ORDER BY  {0} {1}", sort, order));


            return sql;
        }
    }
}
