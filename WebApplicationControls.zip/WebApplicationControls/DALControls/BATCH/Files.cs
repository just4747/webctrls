﻿using System.Data;

namespace DALControls.BATCH
{
    public static class Files
    {
        public static IDataReader SanityCheck()
        {
            return DALControls.ControlsDB.CreateDB().ExecuteReader("reportBATCH_SanityCheck");
        }
    }
}
