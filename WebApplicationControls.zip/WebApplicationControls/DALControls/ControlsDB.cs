﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;

namespace DALControls
{
    public static class ControlsDB
    {
        public static Database CreateDB()
        {
            var factory = new DatabaseProviderFactory();
            return factory.Create("Controls");
        }

        internal static DataTable ExecuteText(string sql)
        {
            return CreateDB().ExecuteDataSet(CommandType.Text, sql).Tables[0];
        }

        public static void test()
        {
            CreateDB().ExecuteNonQuery("Test");
        }
    }
}
