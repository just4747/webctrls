﻿namespace EntityControls.GEAR
{
    public class Application
    {
        public int GEARID { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public bool IsActive { get; set; }
        public string BU { get; set; }
        public string BIO { get; set; }
        public string State { get; set; }
        public string Description { get; set; }
    }
}
