﻿using System;

namespace EntityControls.HR
{
    public class Worker
    {
        static DateTime earlistDate = new DateTime(1900, 1, 1);
        public string EID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public string JobTitle { get; set; }
        public string EmployeeType { get; set; }
        public Guid objectGUID { get; set; }
        private DateTime? _HireDate;
        public DateTime? HireDate
        {
            get
            {
                if (_HireDate >= earlistDate)
                {
                    return _HireDate;
                }
                else
                {
                    return null;
                }
            }
            set
            {
                _HireDate = value;
            }
        }
        public string CBD { get; set; }
        public string Company { get; set; }
        public string Branch { get; set; }
        public string Department { get; set; }
        public string BusinessUnit { get; set; }

        public string City { get; set; }
        public string Country { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsTerminated { get; set; }
        public string FullName
        {
            get
            {
                return string.Format("{0}, {1}", System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(LastName.ToLower()), System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(FirstName.ToLower()));
            }
        }

        public int DirectReports { get; set; }
        public int TotalReports { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string Manager { get; set; }
    }
}
