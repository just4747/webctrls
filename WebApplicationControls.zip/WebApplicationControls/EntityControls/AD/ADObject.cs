﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace EntityControls.AD
{
    public class ADObject
    {
        public Guid objectGUID { get; set; }
        public string Domain { get; set; }
        public string NTID { get; set; }
        public string DistinguishedName { get; set; }
        public string Description { get; set; }
        public int Owners { get; set; }
        public string Combine
        {
            get
            {
                return string.Format("{0}\\{1}", Domain, NTID);
            }
            set
            {
                var regex = new Regex(@"(.+)[\\/](.+)");
                var matches = regex.Match(value);
                if (matches.Success)
                {
                    Domain = matches.Groups[1].Value.Trim();
                    NTID = matches.Groups[2].Value.Trim();
                }
            }
        }

        public ADObject()
        {

        }
        public ADObject(string combine)
        {
            Combine = combine;
        }

        public ADObject(string domain, string NTID)
        {
            Domain = domain;
            this.NTID = NTID;
        }


        public string ouPath
        {
            get
            {
                if (!string.IsNullOrEmpty(DistinguishedName))
                {
                    var regex = new Regex(@"OU=([^,]+)");
                    var matches = regex.Matches(DistinguishedName);
                    if (matches.Count > 0)
                    {
                        var l = new List<string>();
                        foreach (Match match in matches)
                        {
                            l.Add(match.Groups[1].Value);
                        }
                        l.Reverse();
                        return string.Join(" / ", l.ToArray());
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
                else
                {
                    return string.Empty;
                }
            }
        }

    }
}
