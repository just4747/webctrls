﻿
namespace EntityControls.AD
{
    public class Group : ADObject
    {
        public int MemberUsers { get; set; }
        public int MemberGroups { get; set; }
    }
}
