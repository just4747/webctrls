﻿namespace EntityControls.AD
{
    public class User : ADObject
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EID { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public bool IsDisabled { get; set; }
        public string Category { get; set; }
        public string EmploymentStatus { get; set; }
        public string AccountSubType { get; set; }
        public string LastLogon { get; set; }
        public string DisabledOn { get; set; }
        public string ExpiredOn { get; set; }
        public bool IsActive { get; set; }
        public string FullName
        {
            get
            {
                return string.Format("{0}, {1}", LastName, FirstName);
            }
        }
    }
}
